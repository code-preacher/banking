$( function() {
    $( "#datepicker" ).datepicker();
  } );